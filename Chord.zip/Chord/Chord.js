class Key {
	static #Degrees = [7, 1, 1, 2, 2, 2, 3, 4, 3, 3, 4, 4, 5, 5, 5, 6, 6, 6, 7, 1, 7];
	static #SF      = [1, 0, 1,-1, 0, 1,-1,-1, 0, 1, 0, 1,-1, 0, 1,-1, 0, 1,-1,-1, 0];
	#Tones          = [0, 0, 1, 1, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 8, 8, 9,10,10,11,11];
	#Signature = 0;
	/** @type {string[]} */
	#Names = [];

	/**
	 * @param {number} signature
	 * @param {number} key
	 * @param  {...string} names
	 */
	constructor(signature, key, ...names) {
		for (let i=0; i<this.#Tones.length; i++) {
			this.#Tones[i] = (this.#Tones[i] + key + 12) % 12;
		}
		this.#Signature = signature;
		this.#Names = names;
	}

	static #KeyList = [
		//               #Ⅶ    Ⅰ    #Ⅰ     bⅡ     Ⅱ    #Ⅱ    bⅢ    bⅣ     Ⅲ   #Ⅲ    Ⅳ    #Ⅳ    bⅤ    Ⅴ    #Ⅴ    bⅥ     Ⅵ   #Ⅵ   bⅦ     bⅠ    Ⅶ
		new Key( -6, -6, "F#", "Gb", "G",  "Abb", "Ab", "A",  "Bbb", "Cbb", "Bb", "B",  "Cb", "C",  "Dbb", "Db", "D",  "Ebb", "Eb", "E",  "Fb",  "Gbb", "F" ),
		new Key(  1, -5, "Fx", "G",  "G#", "Ab",  "A",  "A#", "Bb",  "Cb",  "B",  "B#", "C",  "C#", "Db",  "D",  "D#", "Eb",  "E",  "E#", "F",   "Gb",  "F#"),
		new Key( -4, -4, "G#", "Ab", "A",  "Bbb", "Bb", "B",  "Cb",  "Dbb", "C",  "C#", "Db", "D",  "Ebb", "Eb", "E",  "Fb",  "F",  "F#", "Gb",  "Abb", "G" ),
		new Key(  3, -3, "Gx", "A",  "A#", "Bb",  "B",  "B#", "C",   "Db",  "C#", "Cx", "D",  "D#", "Eb",  "E",  "E#", "F",   "F#", "Fx", "G",   "Ab",  "G#"),
		new Key( -2, -2, "A#", "Bb", "B",  "Cb",  "C",  "C#", "Db",  "Ebb", "D",  "D#", "Eb", "E",  "Fb",  "F",  "F#", "Gb",  "G",  "G#", "Ab",  "Bbb", "A" ),
		new Key(  5, -1, "Ax", "B",  "B#", "C",   "C#", "Cx", "D",   "Eb",  "D#", "Dx", "E",  "E#", "F",   "F#", "Fx", "G",   "G#", "Gx", "A",   "Bb",  "A#"),
		new Key( -7, -1, "B",  "Cb", "C",  "Dbb", "Db", "D",  "Ebb", "Fbb", "Eb", "E",  "Fb", "F",  "Gbb", "Gb", "G",  "Abb", "Ab", "A",  "Bbb", "Cbb", "Bb"),
		new Key(  0,  0, "B#", "C",  "C#", "Db",  "D",  "D#", "Eb",  "Fb",  "E",  "E#", "F",  "F#", "Gb",  "G",  "G#", "Ab",  "A",  "A#", "Bb",  "Cb",  "B" ),
		new Key(  7,  1, "Bx", "C#", "Cx", "D",   "D#", "Dx", "E",   "F",   "E#", "Ex", "F#", "Fx", "G",   "G#", "Gx", "A",   "A#", "Ax", "B",   "C",   "B#"),
		new Key( -5,  1, "C#", "Db", "D",  "Ebb", "Eb", "E",  "Fb",  "Gbb", "F",  "F#", "Gb", "G",  "Abb", "Ab", "A",  "Bbb", "Bb", "B",  "Cb",  "Dbb", "C" ),
		new Key(  2,  2, "Cx", "D",  "D#", "Eb",  "E",  "E#", "F",   "Gb",  "F#", "Fx", "G",  "G#", "Ab",  "A",  "A#", "Bb",  "B",  "B#", "C",   "Db",  "C#"),
		new Key( -3,  3, "D#", "Eb", "E",  "Fb",  "F",  "F#", "Gb",  "Abb", "G",  "G#", "Ab", "A",  "Bbb", "Bb", "B",  "Cb",  "C",  "C#", "Db",  "Ebb", "D" ),
		new Key(  4,  4, "Dx", "E",  "E#", "F",   "F#", "Fx", "G",   "Ab",  "G#", "Gx", "A",  "A#", "Bb",  "B",  "B#", "C",   "C#", "Cx", "D",   "Eb",  "D#"),
		new Key( -1,  5, "E#", "F",  "F#", "Gb",  "G",  "G#", "Ab",  "Bbb", "A",  "A#", "Bb", "B",  "Cb",  "C",  "C#", "Db",  "D",  "D#", "Eb",  "Fb",  "E" ),
		new Key(  6,  6, "Ex", "F#", "Fx", "G",   "G#", "Gx", "A",   "Bb",  "A#", "Ax", "B",  "B#", "C",   "C#", "Cx", "D",   "D#", "Dx", "E",   "F",   "E#")
	];

	/**
	 * @param {number} signature 
	 * @returns {Key}
	 */
	static Get(signature) {
		for (let i=0; i<Key.#KeyList.length; i++) {
			let k = Key.#KeyList[i];
			if (k.#Signature == signature) {
				return k;
			}
		}
		return null;
	}

	/**
	 * @param {number} tone
	 * @param {number} sf
	 * @returns { {Name:string, Degree:number, SF:number} }
	 */
	GetNote(tone, sf) {
		for (let i=0; i<this.#Tones.length; i++) {
			let s = Key.#SF[i];
			if (this.#Tones[i] == (tone % 12) && (s == 0 || s == sf)) {
				return {
					Name: this.#Names[i],
					Degree: Key.#Degrees[i],
					SF: Key.#SF[i]
				};
			}
		}
		return null;
	}
}

class I {
	#Name = "";
	#Tone = 0;
	#SF = 0;

	get Name() { return this.#Name; }
	get Tone() { return this.#Tone; }
	get SF() { return this.#SF; }

	/**
	 * @param {string} name
	 * @param {number} tone
	 * @param {number} sf
	 */
	constructor(name, tone, sf) {
		this.#Name = name;
		this.#Tone = tone;
		this.#SF = sf;
	}

	static P1 = new I("P1", 0,  0);
	static m2 = new I("m2", 1, -1);
	static M2 = new I("M2", 2,  0);
	static m3 = new I("m3", 3, -1);
	static M3 = new I("M3", 4,  0);
	static P4 = new I("P4", 5,  0);
	static b5 = new I("b5", 6, -1);
	static P5 = new I("P5", 7,  0);
	static S5 = new I("#5", 8,  1);
	static m6 = new I("m6", 8, -1);
	static M6 = new I("M6", 9,  0);
	static b7 = new I("b7", 9, -2);
	static m7 = new I("m7", 10,-1);
	static M7 = new I("M7", 11, 0);
	static M9 = new I("M9", 2,  0);
	static S9 = new I("#9", 3,  1);
	static P11 = new I("P11", 5, 0);
	static S11 = new I("#11", 6, 1);
	static m13 = new I("m13", 8, -1);
	static M13 = new I("M13", 9,  0);
}

class Struct {
	#Name = "";
	/** @type {I[]} */
	#Intervals = [];

	get Name() { return this.#Name; }
	get Intervals() { return this.#Intervals; }

	/**
	 * @param {string} name
	 * @param  {...I} intervals
	 */
	constructor(name, ...intervals) {
		this.#Name = name;
		this.#Intervals = intervals;
	}

	static #List = [
		new Struct("m6(9)",   I.m3, I.P5, I.M6, I.M9),
		new Struct("m7(9)",   I.m3, I.P5, I.m7, I.M9),
		new Struct("m7(11)",  I.m3, I.P5, I.m7, I.P11),
		new Struct("m7(#11)", I.m3, I.P5, I.m7, I.S11),
		new Struct("m7(b13)", I.m3, I.P5, I.m7, I.m13),
		new Struct("m7(13)",  I.m3, I.P5, I.m7, I.M13),
		new Struct("6(9)",    I.M3, I.P5, I.M6, I.M9),
		new Struct("7(9)",    I.M3, I.P5, I.m7, I.M9),
		new Struct("7(#9)",   I.M3, I.P5, I.m7, I.S9),
		new Struct("7(11)",   I.M3, I.P5, I.m7, I.P11),
		new Struct("7(#11)",  I.M3, I.P5, I.m7, I.S11),
		new Struct("7(b13)",  I.M3, I.P5, I.m7, I.m13),
		new Struct("7(13)",   I.M3, I.P5, I.m7, I.M13),

		new Struct("dim7",    I.m3, I.b5, I.b7),
		new Struct("m7(b5)",  I.m3, I.b5, I.m7),
		new Struct("m6",      I.m3, I.P5, I.M6),
		new Struct("m7",      I.m3, I.P5, I.m7),
		new Struct("mΔ7",     I.m3, I.P5, I.M7),
		new Struct("m(add9)", I.m3, I.P5, I.M9),
		new Struct("m(add11)",I.m3, I.P5, I.P11),
		new Struct("7(b5)",   I.M3, I.b5, I.m7),
		new Struct("6",       I.M3, I.P5, I.M6),
		new Struct("7",       I.M3, I.P5, I.m7),
		new Struct("Δ7",      I.M3, I.P5, I.M7),
		new Struct("(add9)",  I.M3, I.P5, I.M9),
		new Struct("(add11)", I.M3, I.P5, I.P11),
		new Struct("aug7",    I.M3, I.S5, I.m7),
		new Struct("7sus4",   I.P4, I.P5, I.m7),

		new Struct("sus2",  I.M2, I.P5),
		new Struct("m(b5)", I.m3, I.b5),
		new Struct("m",     I.m3, I.P5),
		new Struct("(b5)",  I.M3, I.b5),
		new Struct("",      I.M3, I.P5),
		new Struct("aug",   I.M3, I.S5),
		new Struct("sus4",  I.P4, I.P5),

		new Struct("m(omit5)", I.m3),
		new Struct("(omit5)",  I.M3),
		new Struct("5",        I.P5)
	];

	/**
	 * @param {number[]} tones
	 * @returns {Struct}
	 */
	static Get(tones) {
		let bassTone = 128;
		for (let i=0; i<tones.length; i++) {
			bassTone = Math.min(bassTone, tones[i]);
		}
		let notes = [];
		for (let i=0; i<tones.length; i++) {
			let note = (tones[i] - bassTone) % 12;
			if (notes.indexOf(note) < 0) {
				notes.push(note);
			}
		}
		for (let s=0; s<Struct.#List.length; s++) {
			let struct = Struct.#List[s];
			if (notes.length != struct.#Intervals.length + 1) {
				continue;
			}
			let isMatch = true;
			for (let t=0; t<struct.#Intervals.length; t++) {
				if (notes[t+1] != struct.#Intervals[t].Tone) {
					isMatch = false;
					break;
				}
			}
			if (isMatch) {
				return struct;
			}
		}
		return null;
	}
}
