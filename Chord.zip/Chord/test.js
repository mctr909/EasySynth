/// <reference path="Chord.js" />

function main() {
	let k = Key.Get(3);
	let ofs = -3;
	let chords = [
		[24+ofs, 40+ofs, 43+ofs, 47+ofs],
		[26+ofs, 41+ofs, 45+ofs, 48+ofs],
		[26+ofs, 42+ofs, 45+ofs, 48+ofs],
		[28+ofs, 43+ofs, 47+ofs, 50+ofs],
		[28+ofs, 44+ofs, 47+ofs, 50+ofs],
		[29+ofs, 45+ofs, 48+ofs, 52+ofs],
		[31+ofs, 47+ofs, 50+ofs, 53+ofs],
		[33+ofs, 48+ofs, 52+ofs, 55+ofs],
		[35+ofs, 50+ofs, 53+ofs, 57+ofs]
	];
	let style = "style='border-style:solid; border-collapse:collapse; border-width:1px;'";
	let table = "<table " + style + ">";
	for (let j=0; j<chords.length; j++) {
		let chord = chords[j];
		let s = Struct.Get(chord);
		let b = k.GetNote(chord[0], 0);
		table += "<tr " + style + "><td>" + (b.Name + s.Name) + "</td>";
		for (let i=0; i<chord.length; i++) {
			let t = k.GetNote(chord[i], 0);
			if (t == null) {
				t = k.GetNote(chord[i], 1);
			}
			table += "<td " + style + ">" + t.Name + "</td>";
		}
		table += "</tr>";
	}
	return table + "</table>";
}